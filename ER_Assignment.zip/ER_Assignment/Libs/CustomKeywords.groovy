
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String


def static "common.Login.makelogin"(
    	String username	
     , 	String password	) {
    (new common.Login()).makelogin(
        	username
         , 	password)
}

def static "requestform.DropDown.dropdown_Sel"(
    	String sdate	
     , 	String stime	
     , 	String edate	
     , 	String etime	) {
    (new requestform.DropDown()).dropdown_Sel(
        	sdate
         , 	stime
         , 	edate
         , 	etime)
}

def static "requestform.TextFields.Fillfields"(
    	String fname	
     , 	String lname	
     , 	String mail	
     , 	String ename	
     , 	String description	) {
    (new requestform.TextFields()).Fillfields(
        	fname
         , 	lname
         , 	mail
         , 	ename
         , 	description)
}

def static "common.Module_Selection.module_Sel"(
    	String title	) {
    (new common.Module_Selection()).module_Sel(
        	title)
}

def static "common.Module_Selection.Tab_Sel"(
    	String tab	) {
    (new common.Module_Selection()).Tab_Sel(
        	tab)
}

def static "common.Module_Selection.searchEvent"(
    	String search	) {
    (new common.Module_Selection()).searchEvent(
        	search)
}

def static "common.Module_Selection.Act_cancl"(
    	String title	
     , 	String ok	) {
    (new common.Module_Selection()).Act_cancl(
        	title
         , 	ok)
}
