import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import org.openqa.selenium.Keys

import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI


String startTimeXpath = "//input[@name='start_time']" 
setTimeInField(startTimeXpath, "10:31", "am")
String endTimeXpath = "//input[@name='end_time']"
setTimeInField(endTimeXpath, "12:31", "pm")

CustomKeywords.'requestform.TextFields.Fillfields'('Anuvindha', 'S A', 'anuvindha.sa@inapp.com', 'Wedding', 'Wedding Ceremony')

WebUI.selectOptionByValue(findTestObject('request/Dropdown'), 'Seattle', false)

WebUI.setText(findTestObject('request/List'), '')

WebUI.click(findTestObject('request/List'))

WebUI.setText(findTestObject('request/List'), 'Asia/Kolkata')
String startTimeXpath = "//input[@name='start_time']"
setTimeInField(startTimeXpath, "10:31", "am")
String endTimeXpath = "//input[@name='end_time']"
setTimeInField(endTimeXpath, "12:31", "pm")
//CustomKeywords.'requestform.DropDown.dropdown_Sel'('30-03-2020', '10:30', '30-03-2020', '12:00')

WebUI.setText(findTestObject('request/attendance'), '5000')

def setTimeInField(String timeXpath, String timeToSet, String timeFormat){
	WebUI.scrollToElement(findTestObject('Object Repository/dynamicXpathElement',[("xpath"):timeXpath]), 10)
	WebUI.sendKeys(findTestObject('Object Repository/dynamicXpathElement',[("xpath"):timeXpath]), timeToSet)
	WebUI.sendKeys(findTestObject('Object Repository/dynamicXpathElement',[("xpath"):timeXpath]), Keys.chord(Keys.ARROW_DOWN))
	if(timeFormat.equalsIgnoreCase("am")){
		WebUI.sendKeys(findTestObject('Object Repository/dynamicXpathElement',[("xpath"):timeXpath]), Keys.chord(Keys.ARROW_DOWN))
	}
	WebUI.comment("")
}
