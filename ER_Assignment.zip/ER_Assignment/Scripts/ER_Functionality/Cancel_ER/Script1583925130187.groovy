import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable

CustomKeywords.'common.Login.makelogin'('company_admin@tenant1.com', '#$kkre98&*')
WebUI.verifyElementVisible(findTestObject('ER_Cancelfunc/Pagetitle_visiblecheck'))
CustomKeywords.'common.Module_Selection.module_Sel'('Event Request')
CustomKeywords.'common.Module_Selection.Tab_Sel'('Requested')
CustomKeywords.'common.Module_Selection.searchEvent'('Wedding')
WebUI.click(findTestObject('ER_Cancelfunc/Right_Arrow'))
CustomKeywords.'common.Module_Selection.Act_cancl'('Cancel Request', 'Ok')
WebUI.verifyElementVisible(findTestObject('ER_Cancelfunc/Cancelledstate_Verify'))
WebUI.closeBrowser()
